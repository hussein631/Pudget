# Pudget / مصاريفي - Feature Update

Implemented without Firebase, backend, API, or internet dependency:

- Expense Receipt PDF: Today / Week / Month / Custom Range, native PdfDocument, app-private Documents storage, FileProvider sharing.
- Undo Delete: Material Snackbar with restore of the original JSON expense object.
- Theme Customization: Green, Light, Dark, Blue, Purple. Selection is stored locally and applied centrally.
- Expense item name and capture time were added to the existing expense JSON records while preserving old records.

The requested Welcome Sound was intentionally NOT implemented.

The existing password and salawat gate remain intact.

Build requirements:
- Android Studio with Android Gradle Plugin 8.5.2+
- compileSdk 35
- Java 17

Dependencies added:
- androidx.core:core:1.15.0
- com.google.android.material:material:1.12.0
